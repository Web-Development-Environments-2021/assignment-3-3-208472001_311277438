<template>
    <div class="game-preview">
      <div :title="id" class="game-title">
        <b>Game:</b>
      </div>
      <ul class="game-content">
        <li> host: {{ hostTeam }}</li>
        <li> guest: {{ guestTeam }}</li>
        <li> date: {{ date }}</li>
        <li> time: {{ hour }}</li>
        <li> field: {{ field }}</li>
      </ul>
    </div>
</template>

<script>
export default {
  name: "GamePreview",
  props: {
      id: {
        type: Number,
        required: true
      },
      hostTeam: {
        type: String,
        required: true
      },
      guestTeam: {
        type: String,
        required: true
      },
      date: {
        type: String,
        required: true
      },
      hour: {
        type: String,
        required: true
      },
      field: {
        type: String,
        required: true
      }
  },

};
</script>

<style>
.game-preview {
  display: inline-block;
  width: 250px;
  height: 200px;
  position: relative;
  margin: 10px 10px;
  border-style: solid;
  border-radius: 10px;
  border-width: 5px;
  border-color:cadetblue;
}

.game-preview .game-title {
  text-align: center;
  text-transform: uppercase;
  color:  rgb(111, 197, 157);
}

.game-preview .game-content {
  width: 100%;
  overflow: hidden;
}



</style>

<template>
  <div class="container">
    <h1 class="title">Superliga Website</h1>    
    <div id="block_container">
    <div class="blocks"><LeagueInfo></LeagueInfo></div>
    <div class="blocks">
      <LoginPage v-if="!$root.store.username"></LoginPage>
      <FavoriteGames v-else></FavoriteGames>
    </div>
  </div>
</div>
</template>

<script>
import LeagueInfo from "../components/LeagueInfo";
import FavoriteGames from "../components/FavoriteGames";
import LoginPage from "../pages/LoginPage";
export default {
  components: {
    LeagueInfo, 
    LoginPage, 
    FavoriteGames
  }
};
</script>

<style lang="scss" scoped>
.RandomRecipes {
  margin: 10px 0 10px;
}
.blur {
  -webkit-filter: blur(5px); /* Safari 6.0 - 9.0 */
  filter: blur(2px);
}
::v-deep .blur .recipe-preview {
  pointer-events: none;
  cursor: default;
}
#block_container{
  text-align:center;
}
.blocks{
  float: left;
}
</style>
